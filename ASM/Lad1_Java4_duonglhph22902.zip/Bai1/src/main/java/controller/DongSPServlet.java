package controller;

import Repository.DongSPRepository;
import Repository.SanPhamRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.commons.beanutils.BeanUtils;
import view_model.QLDongSP;
import view_model.QLMauSac;
import view_model.QLSanPham;


import java.io.IOException;
import java.util.ArrayList;

@WebServlet({
        "/DongSP/index",    // GET
        "/DongSP/create",   // GET
        "/DongSP/edit",     // GET
        "/DongSP/delete",   // GET
        "/DongSP/store",    // POST
        "/DongSP/update",   // POST
})
public class DongSPServlet extends HttpServlet {
    private DongSPRepository spRepo;
    public DongSPServlet(){

        this.spRepo = new DongSPRepository();
        this.spRepo.insert(new QLDongSP("maDongSP1001","tenDongSP1001"));
        this.spRepo.insert(new QLDongSP("maDongSP1002","tenDongSP1002"));
        this.spRepo.insert(new QLDongSP("maDongSP1003","tenDongSP1003"));
    }
    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("create")) {
            this.create(request, response);
        } else if (uri.contains("edit")) {
            this.edit(request, response);
        } else if (uri.contains("delete")) {
            this.delete(request, response);
        } else {
            this.index(request, response);
        }
    }
    protected void create(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
//        request.getRequestDispatcher("/view/DongSP/create.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/DongSP/create.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }
    protected void index(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        request.setAttribute("danhSachDongSP",this.spRepo.findAll());
//        request.getRequestDispatcher("/view/DongSP/index.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/DongSP/index.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }

    protected void edit(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        QLDongSP kh = this.spRepo.findByMa(ma);
        request.setAttribute("kh", kh);
//        request.getRequestDispatcher("/view/DongSP/edit.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/DongSP/edit.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }
    protected void delete(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        QLDongSP sp = this.spRepo.findByMa(ma);
        this.spRepo.delete(sp);
        response.sendRedirect("/Bai1_war_exploded/DongSP/index");
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("store")) {
            this.store(request, response);
        } else if (uri.contains("update")) {
            this.update(request, response);
        } else {
            response.sendRedirect("/Bai1_war_exploded/DongSP/index");
        }

    }
    protected void store(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        String ten = request.getParameter("ten");


        QLDongSP vm = new QLDongSP(ma, ten);
        this.spRepo.insert(vm);
        response.sendRedirect("/Bai1_war_exploded/DongSP/index");
    }
    protected void update(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        try {
            QLDongSP vm = new QLDongSP();
            BeanUtils.populate(vm, request.getParameterMap());
            this.spRepo.update(vm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("/Bai1_war_exploded/DongSP/index");
    }
}
