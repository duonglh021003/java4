package controller;

import Repository.ChucVuRepository;
import Repository.SanPhamRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.commons.beanutils.BeanUtils;
import view_model.QLChucVu;


import java.io.IOException;

@WebServlet({
        "/chuc-vu/index",    // GET
        "/chuc-vu/create",   // GET
        "/chuc-vu/edit",     // GET
        "/chuc-vu/delete",   // GET
        "/chuc-vu/store",    // POST
        "/chuc-vu/update",   // POST
})
public class ChucVuServlet extends HttpServlet {
    private ChucVuRepository spRepo;
    public ChucVuServlet(){

        this.spRepo = new ChucVuRepository();
        this.spRepo.insert(new QLChucVu("maCV1001","tenCV1001"));
        this.spRepo.insert(new QLChucVu("maCV1002","tenCV1002"));
        this.spRepo.insert(new QLChucVu("maCV1003","tenCV1003"));
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("create")) {
            this.create(request, response);
        } else if (uri.contains("edit")) {
            this.edit(request, response);
        } else if (uri.contains("delete")) {
            this.delete(request, response);
        } else {
            this.index(request, response);
        }
    }
    protected void create(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
//        request.getRequestDispatcher("/view/chuc_vu/create.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/chuc_vu/create.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }
    protected void index(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        request.setAttribute("danhSachSP",this.spRepo.findAll());
//        request.getRequestDispatcher("/view/chuc_vu/index.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/chuc_vu/index.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }
    protected void edit(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        QLChucVu kh = this.spRepo.findByMa(ma);
        request.setAttribute("kh", kh);
//        request.getRequestDispatcher("/view/chuc_vu/edit.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/chuc_vu/edit.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }
    protected void delete(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        QLChucVu sp = this.spRepo.findByMa(ma);
        this.spRepo.delete(sp);
        response.sendRedirect("/Bai1_war_exploded/chuc-vu/index");
    }
    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("store")) {
            this.store(request, response);
        } else if (uri.contains("update")) {
            this.update(request, response);
        } else {
            response.sendRedirect("/Bai1_war_exploded/chuc-vu/index");
        }

    }
    protected void store(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        String ten = request.getParameter("ten");


        QLChucVu vm = new QLChucVu(ma, ten);
        this.spRepo.insert(vm);
        response.sendRedirect("/Bai1_war_exploded/chuc-vu/index");
    }
    protected void update(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        try {
            QLChucVu vm = new QLChucVu();
            BeanUtils.populate(vm, request.getParameterMap());
            this.spRepo.update(vm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("/Bai1_war_exploded/chuc-vu/index");
    }
}
