package controller;

import Repository.ChiTietSPRepository;
import Repository.KhachHangRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.commons.beanutils.BeanUtils;
import view_model.QLChiTietSP;
import view_model.QLKhachHang;

import java.io.IOException;

@WebServlet({
        "/chi-tiet-sp/index",    // GET
        "/chi-tiet-sp/create",   // GET
        "/chi-tiet-sp/edit",     // GET
        "/chi-tiet-sp/delete",   // GET
        "/chi-tiet-sp/store",    // POST
        "/chi-tiet-sp/update",   // POST
})
public class ChiTietSPServlet extends HttpServlet {
    private ChiTietSPRepository chiTietSPRepo;

    public ChiTietSPServlet()
    {
        this.chiTietSPRepo = new ChiTietSPRepository();
        this.chiTietSPRepo.insert(new QLChiTietSP("1","maSP1001","maNsx1001","maMS1001","maDongSP1001","2000","tốt","10","9.5","10.9"));
        this.chiTietSPRepo.insert(new QLChiTietSP("2","maSP1002","maNsx1002","maMS1002","maDongSP1002","2000","tốt","10","9.5","10.9"));
        this.chiTietSPRepo.insert(new QLChiTietSP("3","maSP1003","maNsx1003","maMS1003","maDongSP1003","2000","tốt","10","9.5","10.9"));

    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("create")) {
            this.create(request, response);
        } else if (uri.contains("edit")) {
            this.edit(request, response);
        } else if (uri.contains("delete")) {
            this.delete(request, response);
        } else {
            this.index(request, response);
        }
    }

    protected void edit(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String id = request.getParameter("id");
        QLChiTietSP ctsp = this.chiTietSPRepo.findByMa(id);
        request.setAttribute("ctsp", ctsp);
//        request.getRequestDispatcher("/view/chi_tiet_sp/edit.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/chi_tiet_sp/edit.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }

    protected void delete(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String id = request.getParameter("id");
        QLChiTietSP ctsp = this.chiTietSPRepo.findByMa(id);
        this.chiTietSPRepo.delete(ctsp);
        response.sendRedirect("/Bai1_war_exploded/chi-tiet-sp/index");
    }

    protected void index(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        request.setAttribute("danhSachchiTietSP", this.chiTietSPRepo.findAll());
//        request.getRequestDispatcher("/view/chi_tiet_sp/index.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/chi_tiet_sp/index.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }

    protected void create(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
//        request.getRequestDispatcher("/view/chi_tiet_sp/create.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/chi_tiet_sp/create.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("store")) {
            this.store(request, response);
        } else if (uri.contains("update")) {
            this.update(request, response);
        } else {
            response.sendRedirect("/Bai1_war_exploded/chi-tiet-sp/index");
        }
    }

    protected void store(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {


        String id = request.getParameter("id");
        String idSP = request.getParameter("idSP");
        String idNsx = request.getParameter("idNsx");
        String idMS = request.getParameter("idMS");
        String idDongSP = request.getParameter("idDongSP");
        String nam_bh = request.getParameter("nam_bh");
        String mo_ta = request.getParameter("mo_ta");
        String slton = request.getParameter("slton");
        String gia_nhap = request.getParameter("gia_nhap");
        String gia_ban = request.getParameter("gia_ban");


        QLChiTietSP vm = new QLChiTietSP(id,idSP,idNsx,idMS,idDongSP,nam_bh,mo_ta,slton,gia_nhap,gia_ban);
        this.chiTietSPRepo.insert(vm);
        response.sendRedirect("/Bai1_war_exploded/chi-tiet-sp/index");

    }

    protected void update(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        try {
            QLChiTietSP vm = new QLChiTietSP();
            BeanUtils.populate(vm, request.getParameterMap());
            this.chiTietSPRepo.update(vm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("/Bai1_war_exploded/chi-tiet-sp/index");
    }
}
