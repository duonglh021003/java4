package controller;

import Repository.CuaHangRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.commons.beanutils.BeanUtils;
import view_model.QLCuaHang;


import java.io.IOException;

@WebServlet({
        "/cua-hang/index",    // GET
        "/cua-hang/create",   // GET
        "/cua-hang/edit",     // GET
        "/cua-hang/delete",   // GET
        "/cua-hang/store",    // POST
        "/cua-hang/update",   // POST
})
public class CuaHangServlet extends HttpServlet {
    private CuaHangRepository chRepo;

    public CuaHangServlet()
    {
        this.chRepo = new CuaHangRepository();
        this.chRepo.insert(new QLCuaHang("maCH1001","tenCH1001","HN","HN","VN"));
        this.chRepo.insert(new QLCuaHang("maCH1002","tenCH1002","HN","HN","VN"));
        this.chRepo.insert(new QLCuaHang("maCH1003","tenCH1003","HN","HN","VN"));
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("create")) {
            this.create(request, response);
        } else if (uri.contains("edit")) {
            this.edit(request, response);
        } else if (uri.contains("delete")) {
            this.delete(request, response);
        } else {
            this.index(request, response);
        }
    }

    protected void edit(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        QLCuaHang ch = this.chRepo.findByMa(ma);
        request.setAttribute("ch", ch);
//        request.getRequestDispatcher("/view/cua_hang/edit.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/cua_hang/edit.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }

    protected void delete(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        QLCuaHang ch = this.chRepo.findByMa(ma);
        this.chRepo.delete(ch);
        response.sendRedirect("/Bai1_war_exploded/cua-hang/index");
    }

    protected void index(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        request.setAttribute("danhSachCH", this.chRepo.findAll());
//        request.getRequestDispatcher("/view/cua_hang/index.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/cua_hang/index.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }

    protected void create(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
//        request.getRequestDispatcher("/view/cua_hang/create.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/cua_hang/create.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("store")) {
            this.store(request, response);
        } else if (uri.contains("update")) {
            this.update(request, response);
        } else {
            response.sendRedirect("/Bai1_war_exploded/cua-hang/index");
        }
    }

    protected void store(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        String ten = request.getParameter("ten");
        String dia_chi = request.getParameter("dia_chi");
        String thanh_pho = request.getParameter("thanh_pho");
        String quoc_gia = request.getParameter("quoc_gia");

        QLCuaHang vm = new QLCuaHang(ma, ten, dia_chi, thanh_pho, quoc_gia);
        this.chRepo.insert(vm);
        response.sendRedirect("/Bai1_war_exploded/cua-hang/index");

    }

    protected void update(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        try {
            QLCuaHang vm = new QLCuaHang();
            BeanUtils.populate(vm, request.getParameterMap());
            this.chRepo.update(vm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("/Bai1_war_exploded/cua-hang/index");
    }
}
