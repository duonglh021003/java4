package controller;


import Repository.MauSacRepository;
import
jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.commons.beanutils.BeanUtils;
import view_model.QLMauSac;
import view_model.QLSanPham;


import java.io.IOException;
import java.util.ArrayList;
@WebServlet({
        "/mau-sac/index",    // GET
        "/mau-sac/create",   // GET
        "/mau-sac/edit",     // GET
        "/mau-sac/delete",   // GET
        "/mau-sac/store",    // POST
        "/mau-sac/update",   // POST
})
public class MauSacServlet extends HttpServlet {
    private MauSacRepository spRepo;
    public MauSacServlet(){

        this.spRepo = new MauSacRepository();
        this.spRepo.insert(new QLMauSac("maMS1001","tenMS1001"));
        this.spRepo.insert(new QLMauSac("maMS1002","tenMS1002"));
        this.spRepo.insert(new QLMauSac("maMS1003","tenMS1003"));
    }
    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("create")) {
            this.create(request, response);
        } else if (uri.contains("edit")) {
            this.edit(request, response);
        } else if (uri.contains("delete")) {
            this.delete(request, response);
        } else {
            this.index(request, response);
        }


    }
    protected void create(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
//        request.getRequestDispatcher("/view/mau_sac/create.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/mau_sac/create.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }
    protected void index(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        request.setAttribute("danhSachMS",this.spRepo.findAll());
//        request.getRequestDispatcher("/view/mau_sac/index.jsp")
//                .forward(request, response);
        request.setAttribute("view", "/view/mau_sac/index.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }
    protected void edit(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        QLMauSac kh = this.spRepo.findByMa(ma);
        request.setAttribute("kh", kh);
        request.setAttribute("view", "/view/mau_sac/edit.jsp");
        request.getRequestDispatcher("/view/layout.jsp")
                .forward(request, response);
    }
    protected void delete(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        QLMauSac sp = this.spRepo.findByMa(ma);
        this.spRepo.delete(sp);
        response.sendRedirect("/Bai1_war_exploded/mau-sac/index");
    }
    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("store")) {
            this.store(request, response);
        } else if (uri.contains("update")) {
            this.update(request, response);
        } else {
            response.sendRedirect("/Bai1_war_exploded/mau-sac/index");
        }

    }
    protected void store(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        String ten = request.getParameter("ten");

        QLMauSac vm = new QLMauSac(ma, ten);
        this.spRepo.insert(vm);
        response.sendRedirect("/Bai1_war_exploded/mau-sac/index");
    }
    protected void update(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        try {
            QLMauSac vm = new QLMauSac();
            BeanUtils.populate(vm, request.getParameterMap());
            this.spRepo.update(vm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("/Bai1_war_exploded/mau-sac/index");
    }
}
