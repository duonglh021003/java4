package Repository;

import view_model.QLKhachHang;
import view_model.QLSanPham;

import java.util.ArrayList;

public class SanPhamRepository {

    private ArrayList<QLSanPham> list;

    public SanPhamRepository()
    {
        this.list = new ArrayList<>();
    }

    public void insert(QLSanPham sp)
    {
        // INSERT INTO KhachHang(ma, ho, ten_dem, ten, ...) VALUES (?, ?, ?, ?, ...)
        this.list.add(sp);
    }

    public void update(QLSanPham sp)
    {
        // UPDATE KhachHang SET ho = ?, ten_dem = ?, ten = ?, ... WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLSanPham item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.set(i, sp);
            }
        }
    }

    public void delete(QLSanPham sp)
    {
        // DELETE FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLSanPham item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.remove(i);
            }
        }
    }


    public ArrayList<QLSanPham> findAll() {
        return list;
    }

    public QLSanPham findByMa(String ma)
    {
        // SELECT * FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLSanPham item = this.list.get(i);
            if (item.getMa().equals(ma)) {
                return this.list.get(i);
            }
        }

        return null;
    }
}
