package Repository;

import view_model.QLChiTietSP;
import view_model.QLKhachHang;

import java.util.ArrayList;

public class ChiTietSPRepository {
    private ArrayList<QLChiTietSP> list;
    public ChiTietSPRepository(){
        this.list = new ArrayList<>();
    }
    public void insert(QLChiTietSP chiTietSP)
    {
        // INSERT INTO KhachHang(ma, ho, ten_dem, ten, ...) VALUES (?, ?, ?, ?, ...)
        this.list.add(chiTietSP);
    }

    public void update(QLChiTietSP chiTietSP)
    {
        // UPDATE KhachHang SET ho = ?, ten_dem = ?, ten = ?, ... WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLChiTietSP item = this.list.get(i);
            if (item.getId().equals(chiTietSP.getId())) {
                this.list.set(i, chiTietSP);
            }
        }
    }

    public void delete(QLChiTietSP chiTietSP)
    {
        // DELETE FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLChiTietSP item = this.list.get(i);
            if (item.getId().equals(chiTietSP.getId())) {
                this.list.remove(i);
            }
        }
    }

    public ArrayList<QLChiTietSP> findAll() {
        return list;
    }

    public QLChiTietSP findByMa(String Id)
    {
        // SELECT * FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLChiTietSP item = this.list.get(i);
            if (item.getId().equals(Id)) {
                return this.list.get(i);
            }
        }

        return null;
    }
}
