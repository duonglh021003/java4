package Repository;

import view_model.QLKhachHang;
import view_model.QLNhanVien;

import java.util.ArrayList;

public class NhanVienRepository {

    private ArrayList<QLNhanVien> list;

    public NhanVienRepository()
    {
        this.list = new ArrayList<>();
    }

    public void insert(QLNhanVien nv)
    {
        // INSERT INTO KhachHang(ma, ho, ten_dem, ten, ...) VALUES (?, ?, ?, ?, ...)
        this.list.add(nv);
    }

    public void update(QLNhanVien nv)
    {
        // UPDATE KhachHang SET ho = ?, ten_dem = ?, ten = ?, ... WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLNhanVien item = this.list.get(i);
            if (item.getMa().equals(nv.getMa())) {
                this.list.set(i, nv);
            }
        }
    }

    public void delete(QLNhanVien nv)
    {
        // DELETE FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLNhanVien item = this.list.get(i);
            if (item.getMa().equals(nv.getMa())) {
                this.list.remove(i);
            }
        }
    }

    public ArrayList<QLNhanVien> findAll() {
        return list;
    }

    public QLNhanVien findByMa(String ma)
    {
        // SELECT * FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLNhanVien item = this.list.get(i);
            if (item.getMa().equals(ma)) {
                return this.list.get(i);
            }
        }

        return null;
    }
}
