package Repository;



import view_model.QLMauSac;

import java.util.ArrayList;

public class MauSacRepository {
    private ArrayList<QLMauSac> list;

    public MauSacRepository()
    {
        this.list = new ArrayList<>();
    }

    public void insert(QLMauSac sp)
    {
        // INSERT INTO KhachHang(ma, ho, ten_dem, ten, ...) VALUES (?, ?, ?, ?, ...)
        this.list.add(sp);
    }

    public void update(QLMauSac sp)
    {
        // UPDATE KhachHang SET ho = ?, ten_dem = ?, ten = ?, ... WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLMauSac item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.set(i, sp);
            }
        }
    }

    public void delete(QLMauSac sp)
    {
        // DELETE FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLMauSac item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.remove(i);
            }
        }
    }

    public ArrayList<QLMauSac> findAll(){
        return list;
    }

    public QLMauSac findByMa(String ma)
    {
        // SELECT * FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLMauSac item = this.list.get(i);
            if (item.getMa().equals(ma)) {
                return this.list.get(i);
            }
        }

        return null;
    }
}
