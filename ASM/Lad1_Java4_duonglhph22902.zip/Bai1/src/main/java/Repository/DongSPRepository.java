package Repository;


import view_model.QLDongSP;

import java.util.ArrayList;

public class DongSPRepository {
    private ArrayList<QLDongSP> list;

    public DongSPRepository()
    {
        this.list = new ArrayList<>();
    }

    public void insert(QLDongSP sp)
    {
        // INSERT INTO KhachHang(ma, ho, ten_dem, ten, ...) VALUES (?, ?, ?, ?, ...)
        this.list.add(sp);
    }

    public void update(QLDongSP sp)
    {
        // UPDATE KhachHang SET ho = ?, ten_dem = ?, ten = ?, ... WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLDongSP item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.set(i, sp);
            }
        }
    }

    public void delete(QLDongSP sp)
    {
        // DELETE FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLDongSP item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.remove(i);
            }
        }
    }


    public ArrayList<QLDongSP> findAll() {
        return list;
    }

    public QLDongSP findByMa(String ma)
    {
        // SELECT * FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLDongSP item = this.list.get(i);
            if (item.getMa().equals(ma)) {
                return this.list.get(i);
            }
        }

        return null;
    }
}
