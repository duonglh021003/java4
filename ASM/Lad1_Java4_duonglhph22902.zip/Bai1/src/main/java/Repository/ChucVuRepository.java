package Repository;

import view_model.QLChucVu;

import java.util.ArrayList;

public class ChucVuRepository {
    private ArrayList<QLChucVu> list;

    public ChucVuRepository()
    {
        this.list = new ArrayList<>();
    }

    public void insert(QLChucVu sp)
    {
        // INSERT INTO KhachHang(ma, ho, ten_dem, ten, ...) VALUES (?, ?, ?, ?, ...)
        this.list.add(sp);
    }

    public void update(QLChucVu sp)
    {
        // UPDATE KhachHang SET ho = ?, ten_dem = ?, ten = ?, ... WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLChucVu item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.set(i, sp);
            }
        }
    }

    public void delete(QLChucVu sp)
    {
        // DELETE FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLChucVu item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.remove(i);
            }
        }
    }


    public ArrayList<QLChucVu> findAll() {
        return list;
    }

    public QLChucVu findByMa(String ma)
    {
        // SELECT * FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLChucVu item = this.list.get(i);
            if (item.getMa().equals(ma)) {
                return this.list.get(i);
            }
        }

        return null;
    }
}
