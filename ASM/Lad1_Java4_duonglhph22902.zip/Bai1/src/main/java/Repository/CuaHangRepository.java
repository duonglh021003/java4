package Repository;



import view_model.QLCuaHang;

import java.util.ArrayList;

public class CuaHangRepository {

    private ArrayList<QLCuaHang> list;

    public CuaHangRepository()
    {
        this.list = new ArrayList<>();
    }

    public void insert(QLCuaHang ch)
    {
        // INSERT INTO KhachHang(ma, ho, ten_dem, ten, ...) VALUES (?, ?, ?, ?, ...)
        this.list.add(ch);
    }

    public void update(QLCuaHang ch)
    {
        // UPDATE KhachHang SET ho = ?, ten_dem = ?, ten = ?, ... WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLCuaHang item = this.list.get(i);
            if (item.getMa().equals(ch.getMa())) {
                this.list.set(i, ch);
            }
        }
    }

    public void delete(QLCuaHang ch)
    {
        // DELETE FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLCuaHang item = this.list.get(i);
            if (item.getMa().equals(ch.getMa())) {
                this.list.remove(i);
            }
        }
    }

    public ArrayList<QLCuaHang> findAll() {
        return list;
    }

    public QLCuaHang findByMa(String ma)
    {
        // SELECT * FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLCuaHang item = this.list.get(i);
            if (item.getMa().equals(ma)) {
                return this.list.get(i);
            }
        }

        return null;
    }
}
