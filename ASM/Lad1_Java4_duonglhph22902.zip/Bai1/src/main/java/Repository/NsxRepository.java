package Repository;

import view_model.QLNsx;


import java.util.ArrayList;

public class NsxRepository {
    private ArrayList<QLNsx> list;

    public NsxRepository()
    {
        this.list = new ArrayList<>();
    }

    public void insert(QLNsx sp)
    {
        // INSERT INTO KhachHang(ma, ho, ten_dem, ten, ...) VALUES (?, ?, ?, ?, ...)
        this.list.add(sp);
    }

    public void update(QLNsx sp)
    {
        // UPDATE KhachHang SET ho = ?, ten_dem = ?, ten = ?, ... WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLNsx item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.set(i, sp);
            }
        }
    }

    public void delete(QLNsx sp)
    {
        // DELETE FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLNsx item = this.list.get(i);
            if (item.getMa().equals(sp.getMa())) {
                this.list.remove(i);
            }
        }
    }


    public ArrayList<QLNsx> findAll() {
        return list;
    }

    public QLNsx findByMa(String ma)
    {
        // SELECT * FROM KhachHang WHERE ma = ?;
        for (int i = 0; i < this.list.size(); i++) {
            QLNsx item = this.list.get(i);
            if (item.getMa().equals(ma)) {
                return this.list.get(i);
            }
        }

        return null;
    }
}
